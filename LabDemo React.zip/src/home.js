import React from "react";
import { Link } from "react-router-dom";
import bike1Image from "./images.jpeg";
import bike2Image from "./ge5115872937544120580.jpg";
import bike3Image from "./pngtree-d-illustration-of-a-white-backgrounded-super-sports-motorbike-in-blue-picture-image_6937785.jpg";
import bike4Image from "./images (1).jpeg";

const Home = () => {
  return (
    <div className="home-page">
      <main>
        <section className="hero">
          <h1><b>Welcome to the bike Zone</b></h1>
          <p>Explore our collection of Bikes and start renting today!</p>
          <button><b>Rent Your Favourite Bike Now</b></button>
        </section>
        <section className="featured-products">
          <h2>Featured Bikes</h2>
          <ul>
            <li>
              <Link to="/product/bike1">
                <img src={bike1Image} alt="Bike 1" />
                <h3>Bike 1</h3>
                <p>$100</p>
                <button><b>Rent Now</b></button>
              </Link>
            </li>
            <li>
              <Link to="/product/bike2">
                <img src={bike2Image} alt="Bike 2" />
                <h3>Bike 2</h3>
                <p>$180.67</p>
                <button><b>Rent Now</b></button>
              </Link>
            </li>
            <li>
              <Link to="/product/bike3">
                <img src={bike3Image} alt="Bike 3" />
                <h3>Bike 3</h3>
                <p>$200</p>
                <button><b>Rent Now</b></button>
              </Link>
            </li>
            <li>
              <Link to="/product/bike4">
                <img src={bike4Image} alt="Bike 4" />
                <h3>Bike 4</h3>
                <p>$150</p>
                <button><b>Rent Now</b></button>
              </Link>
            </li>
          </ul>
        </section>
      </main>
      <footer>
        <span>&copy;copyright 2024-25 www.bikezone.com</span>
      </footer>
    </div>
  );
};

export default Home;
